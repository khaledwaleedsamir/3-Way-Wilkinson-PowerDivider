# Automatically generated file proj.py"

# Generated with $Id: extrusion_to_empro.cpp,v 1.97 2011/02/04 09:15:45 hardevos Exp $ 

import empro, empro.toolkit

def ads_simulation_settings():
	# Frequency plan:
	frequency_plan_list=empro.activeProject.createSimulationData().femFrequencyPlanList()
	frequency_plan=empro.simulation.FrequencyPlan()
	frequency_plan.type="Adaptive"
	frequency_plan.startFrequency=0
	frequency_plan.stopFrequency=10000000000
	frequency_plan.samplePointsLimit=50
	frequency_plan_list.append(frequency_plan)
	empro.activeProject.createSimulationData().saveFieldsFor="UserDefinedFrequencies"
	# Simulation options:
	sim=empro.activeProject.createSimulationData()
	sim.engine = empro.toolkit.simulation.FEM
	sim.femMeshSettings.minimumNumberOfPasses      = 5
	sim.femMeshSettings.maximumNumberOfPasses      = 15
	sim.femMeshSettings.deltaError                 = 0.01
	sim.femMeshSettings.refineAtSpecificFrequency  = False
	sim.femMeshSettings.refinementFrequency        = "0 GHz"
	sim.femMeshSettings.requiredConsecutivePasses  = 1
	sim.femMeshSettings.meshRefinementPercentage   = 25
	sim.femMeshSettings.orderOfBasisFunctions      = 2
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"useMinMeshSize"):
		sim.femMeshSettings.useMinMeshSize               = False
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"minMeshSize"):
		sim.femMeshSettings.minMeshSize                  = "6.95298194335927e-310 m" 
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"useTargetMeshSize"):
		sim.femMeshSettings.useTargetMeshSize            = False
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"targetMeshSize"):
		sim.femMeshSettings.targetMeshSize               = "0 m" 
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"edgeMeshLength"):
		sim.femMeshSettings.edgeMeshLength               = "0 m" 
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"vertexMeshLength"):
		sim.femMeshSettings.vertexMeshLength               = "0 m" 
	if hasattr(empro.libpyempro.simulation.FemMeshSettings,"mergeObjectsWithSameMaterial"):
		sim.femMeshSettings.mergeObjectsWithSameMaterial = False
	if hasattr(empro.libpyempro.simulation.SimulationData,"dataSetFileName"):
		sim.dataSetFileName                            = ''
	sim.femMatrixSolver.solverType                    = "MatrixSolverIterative"
	sim.femMatrixSolver.maximumNumberOfIterations     = 150
	sim.femMatrixSolver.tolerance                     = 1e-05
	if hasattr(empro.activeProject.createSimulationData().femMeshSettings,"refinementStrategy"):
		empro.activeProject.createSimulationData().femMeshSettings.refinementStrategy="maxFrequency"

def ads_import():
	ads_simulation_settings()
	session=empro.toolkit.ads_import.Import_session(units="mil", wall_boundary="Radiation")
	V=empro.geometry.Vector3d
	L=empro.geometry.Line
	roughnesses={}
	materials={}
	def checked_roughness(roughnessTypeString,*args):
		if hasattr(empro.material,roughnessTypeString):
			roughnessConstructor = getattr(empro.material,roughnessTypeString)
			return roughnessConstructor(*args)
		else:
			print "Warning: unsupported surface roughness type %s. Roughness will be ignored." % roughnessTypeString
			return None
	material=session.create_material(name="cond", color=(238,106,80,255), conductivity=41000000, imag_conductivity=0)
	empro.activeProject.materials().append(material)
	materials["cond"]=material
	empro.activeProject.boundaryConditions().zLowerBoundaryType="PEC"
	session.warnings.append("Slot layer \"closed_bottom\" has been converted to PEC.")
	material=session.create_material(name="closed_bottom", color=(192,192,192,255), resistance=0)
	empro.activeProject.materials().append(material)
	materials["closed_bottom"]=material
	material=session.create_material(name="__TOP", color=(202,225,255,255), permittivity=1, permeability=1)
	empro.activeProject.materials().append(material)
	materials["__TOP"]=material
	material=session.create_material(name="__SubstrateLayer1", color=(202,225,255,255), permittivity=4.58, losstangent=0.022, permeability=1, use_djordjevic=True, lowfreq=1000, evalfreq=1000000000, highfreq=1000000000000)
	empro.activeProject.materials().append(material)
	materials["__SubstrateLayer1"]=material
	session.warnings.append("Calibrated port \"P5\" is not on the simulation box boundary and has therefore been interpreted as an internal port.")
	session.warnings.append("Calibrated port \"P6\" is not on the simulation box boundary and has therefore been interpreted as an internal port.")
	empro.activeProject.parameters().append("lateralExtension","123.031496062992 mil","Substrate LATERAL extension",True)
	empro.activeProject.parameters().append("verticalExtension","196.850393700787 mil","Substrate VERTICAL extension",True)
	empro.activeProject.parameters().append("xLowerExtension","0 mil","Lower X extension",False)
	empro.activeProject.parameters().append("xUpperExtension","0 mil","Upper X extension",False)
	empro.activeProject.parameters().append("yLowerExtension","lateralExtension","Lower Y extension",True)
	empro.activeProject.parameters().append("yUpperExtension","lateralExtension","Upper Y extension",True)
	empro.activeProject.parameters().append("zLowerExtension","0 mil","Lower Z extension",False)
	empro.activeProject.parameters().append("zUpperExtension","verticalExtension","Upper Z extension",True)
	assembly=empro.geometry.Assembly()
	sketch=empro.geometry.Sketch()
	edges=[]
	edges.append(L(V(-0.005715,"-0.0025137364-yLowerExtension",0),V(0.0099197414,"-0.0025137364-yLowerExtension",0)))
	edges.append(L(V(0.0099197414,"-0.0025137364-yLowerExtension",0),V(0.0099197414,"0.0032757364+yUpperExtension",0)))
	edges.append(L(V(0.0099197414,"0.0032757364+yUpperExtension",0),V(-0.005715,"0.0032757364+yUpperExtension",0)))
	edges.append(L(V(-0.005715,"0.0032757364+yUpperExtension",0),V(-0.005715,"-0.0025137364-yLowerExtension",0)))
	sketch.addEdges(edges)
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex0",V(-0.005715,"-0.0025137364-yLowerExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex1",V(0.0099197414,"-0.0025137364-yLowerExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex2",V(0.0099197414,"0.0032757364+yUpperExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex3",V(-0.005715,"0.0032757364+yUpperExtension",0)))
	part=empro.geometry.Model()
	part.recipe.append(empro.geometry.Extrude(sketch,"zUpperExtension",V(0,0,1)))
	part.coordinateSystem.translate(V(0,0,0.0008))
	part.name="__TOP"
	part.meshParameters=empro.mesh.ModelMeshParameters()
	part.meshParameters.priority=50
	empro.toolkit.applyMaterial(part,materials["__TOP"])
	assembly.append(part)
	sketch=empro.geometry.Sketch()
	edges=[]
	edges.append(L(V(-0.005715,"-0.0025137364-yLowerExtension",0),V(0.0099197414,"-0.0025137364-yLowerExtension",0)))
	edges.append(L(V(0.0099197414,"-0.0025137364-yLowerExtension",0),V(0.0099197414,"0.0032757364+yUpperExtension",0)))
	edges.append(L(V(0.0099197414,"0.0032757364+yUpperExtension",0),V(-0.005715,"0.0032757364+yUpperExtension",0)))
	edges.append(L(V(-0.005715,"0.0032757364+yUpperExtension",0),V(-0.005715,"-0.0025137364-yLowerExtension",0)))
	sketch.addEdges(edges)
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex0",V(-0.005715,"-0.0025137364-yLowerExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex1",V(0.0099197414,"-0.0025137364-yLowerExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex2",V(0.0099197414,"0.0032757364+yUpperExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex3",V(-0.005715,"0.0032757364+yUpperExtension",0)))
	part=empro.geometry.Model()
	part.recipe.append(empro.geometry.Extrude(sketch,0.0008,V(0,0,1)))
	part.name="__SubstrateLayer1"
	part.meshParameters=empro.mesh.ModelMeshParameters()
	part.meshParameters.priority=50
	empro.toolkit.applyMaterial(part,materials["__SubstrateLayer1"])
	assembly.append(part)
	assembly.name="substrate"
	session.hide_part(assembly)
	empro.activeProject.geometry().append(assembly)
	session.adjust_view()
	ports=[]
	assembly=empro.geometry.Assembly()
	waveform=empro.waveform.Waveform("Broadband Pulse")
	waveform.shape=empro.waveform.MaximumFrequencyWaveformShape()
	empro.activeProject.waveforms().append(waveform)
	feed=empro.components.Feed()
	feed.name="50 ohm Voltage Source"
	feed.impedance.resistance=50
	feed.waveform=empro.activeProject.waveforms()["Broadband Pulse"]
	empro.activeProject.circuitComponentDefinitions().append(feed)
	sketch=empro.geometry.Sketch()
	sketch.addEdge(L(V(-0.005715,"max(-0.0392930634,-0.0025137364-yLowerExtension)",0),V(-0.005715,"min(0.0400550634,0.0032757364+yUpperExtension)",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex0",V(-0.005715,"max(-0.0392930634,-0.0025137364-yLowerExtension)",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex1",V(-0.005715,"min(0.0400550634,0.0032757364+yUpperExtension)",0)))
	extrusion=empro.geometry.Extrude(sketch,"min(0.0808,0.0008+zUpperExtension)",V(0,0,1))
	extrusion.options.solid=False
	part=empro.geometry.Model()
	part.recipe.append(extrusion)
	part.meshParameters=empro.mesh.ModelMeshParameters()
	part.meshParameters.includeInMesh=False
	assembly.append(part)
	waveguide=empro.components.WaveGuide()
	waveguide.name="P1"
	waveguide.definition=empro.activeProject.circuitComponentDefinitions()["50 ohm Voltage Source"]
	waveguide.offset=0
	waveguide.faces=[(part,part.faces()[0])]
	waveguide.setGridGenerator(empro.activeProject.gridGenerator())
	waveguide.paddingBox=empro.geometry.BoundingBox2D(empro.geometry.Vector2d(0,0),empro.geometry.Vector2d(0,0))
	waveguide.usePaddingBox=True
	mode=empro.components.WaveGuideMode()
	mode.head=V(-0.005715,0.000381,0.0008)
	mode.tail=V(-0.005715,0.000381,0)
	waveguide.appendMode(mode)
	empro.activeProject.waveGuides().append(waveguide)
	sketch=empro.geometry.Sketch()
	sketch.addEdge(L(V(0.0099197414,"max(-0.0402852636,-0.0025137364-yLowerExtension)",0),V(0.0099197414,"min(0.0410472636,0.0032757364+yUpperExtension)",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex0",V(0.0099197414,"max(-0.0402852636,-0.0025137364-yLowerExtension)",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex1",V(0.0099197414,"min(0.0410472636,0.0032757364+yUpperExtension)",0)))
	extrusion=empro.geometry.Extrude(sketch,"min(0.0808,0.0008+zUpperExtension)",V(0,0,1))
	extrusion.options.solid=False
	part=empro.geometry.Model()
	part.recipe.append(extrusion)
	part.meshParameters=empro.mesh.ModelMeshParameters()
	part.meshParameters.includeInMesh=False
	assembly.append(part)
	waveguide=empro.components.WaveGuide()
	waveguide.name="P2_P3_P4"
	waveguide.definition=empro.activeProject.circuitComponentDefinitions()["50 ohm Voltage Source"]
	waveguide.offset=0
	waveguide.faces=[(part,part.faces()[0])]
	waveguide.setGridGenerator(empro.activeProject.gridGenerator())
	waveguide.paddingBox=empro.geometry.BoundingBox2D(empro.geometry.Vector2d(0,0),empro.geometry.Vector2d(0,0))
	waveguide.usePaddingBox=True
	mode=empro.components.WaveGuideMode()
	mode.head=V(0.0099197414,0.00137574528,0.0008)
	mode.tail=V(0.0099197414,0.00137574528,0)
	waveguide.appendMode(mode)
	mode=empro.components.WaveGuideMode()
	mode.head=V(0.0099197414,0.000381,0.0008)
	mode.tail=V(0.0099197414,0.000381,0)
	waveguide.appendMode(mode)
	mode=empro.components.WaveGuideMode()
	mode.head=V(0.0099197414,-0.00061374528,0.0008)
	mode.tail=V(0.0099197414,-0.00061374528,0)
	waveguide.appendMode(mode)
	empro.activeProject.waveGuides().append(waveguide)
	feed=empro.components.Feed()
	feed.name="83.6 ohm Voltage Source"
	feed.impedance.resistance=83.6
	feed.waveform=empro.activeProject.waveforms()["Broadband Pulse"]
	empro.activeProject.circuitComponentDefinitions().append(feed)
	port=empro.components.CircuitComponent()
	port.name="P5"
	port.definition=empro.activeProject.circuitComponentDefinitions()["83.6 ohm Voltage Source"]
	port.head=V(0.00972237324,0.0011783822,0.0008)
	port.tail=V(0.00972237324,0.0011783822,0)
	port.extent=empro.components.SheetExtent()
	port.extent.endPoint1Position=V(0.00952500508,0.0011783822,0)
	port.extent.endPoint2Position=V(0.0099197414,0.0011783822,0.0008)
	port.useExtent=True
	ports.append(port)
	port=empro.components.CircuitComponent()
	port.name="P6"
	port.definition=empro.activeProject.circuitComponentDefinitions()["83.6 ohm Voltage Source"]
	port.head=V(0.00972237324,0.0005783834,0.0008)
	port.tail=V(0.00972237324,0.0005783834,0)
	port.extent=empro.components.SheetExtent()
	port.extent.endPoint1Position=V(0.00952500508,0.0005783834,0)
	port.extent.endPoint2Position=V(0.0099197414,0.0005783834,0.0008)
	port.useExtent=True
	ports.append(port)
	port=empro.components.CircuitComponent()
	port.name="P7"
	port.definition=empro.activeProject.circuitComponentDefinitions()["83.6 ohm Voltage Source"]
	port.head=V(0.00972237324,0.0001836166,0.0008)
	port.tail=V(0.00972237324,-0.0004163822,0.0008)
	port.extent=empro.components.SheetExtent()
	port.extent.endPoint1Position=V(0.00952500508,-0.0004163822,0.0008)
	port.extent.endPoint2Position=V(0.0099197414,0.0001836166,0.0008)
	port.useExtent=True
	ports.append(port)
	empro.activeProject.circuitComponents().appendList(ports)
	assembly.name="waveguide_planes"
	session.hide_part(assembly)
	empro.activeProject.geometry().append(assembly)
	assembly=empro.geometry.Assembly()
	sketch=empro.geometry.Sketch()
	edges=[]
	edges.append(L(V(0.0099197414,0.0015731236,0),V(0.00932923458,0.0015731236,0)))
	edges.append(L(V(0.00932923458,0.0015731236,0),V(0.009525,0.001574673,0)))
	edges.append(L(V(0.009525,0.001574673,0),V(0.0095197422,0.0022399244,0)))
	edges.append(L(V(0.0095197422,0.0022399244,0),V(0.00951967362,0.0022399244,0)))
	edges.append(L(V(0.00951967362,0.0022399244,0),V(0.0095158052,0.0023287736,0)))
	edges.append(L(V(0.0095158052,0.0023287736,0),V(0.0095039942,0.0024185118,0)))
	edges.append(L(V(0.0095039942,0.0024185118,0),V(0.0094844108,0.0025068784,0)))
	edges.append(L(V(0.0094844108,0.0025068784,0),V(0.0094225618,0.002676779,0)))
	edges.append(L(V(0.0094225618,0.002676779,0),V(0.0092159074,0.0029719016,0)))
	edges.append(L(V(0.0092159074,0.0029719016,0),V(0.00887936502,0.0031967805,0)))
	edges.append(L(V(0.00887936502,0.0031967805,0),V(0.0084823808,0.0032757364,0)))
	edges.append(L(V(0.0084823808,0.0032757364,0),V(-0.0030176216,0.0032757364,0)))
	edges.append(L(V(-0.0030176216,0.0032757364,0),V(-0.00371575838,0.00318383666,0)))
	edges.append(L(V(-0.00371575838,0.00318383666,0),V(-0.00436631842,0.0029143706,0)))
	edges.append(L(V(-0.00436631842,0.0029143706,0),V(-0.0049249584,0.0024856948,0)))
	edges.append(L(V(-0.0049249584,0.0024856948,0),V(-0.00535362658,0.0019270599,0)))
	edges.append(L(V(-0.00535362658,0.0019270599,0),V(-0.00562309518,0.00127651002,0)))
	edges.append(L(V(-0.00562309518,0.00127651002,0),V(-0.005715,0.0005783834,0)))
	edges.append(L(V(-0.005715,0.0005783834,0),V(-0.005715,0.0001836166,0)))
	edges.append(L(V(-0.005715,0.0001836166,0),V(-0.00562309518,-0.00051451256,0)))
	edges.append(L(V(-0.00562309518,-0.00051451256,0),V(-0.00535362912,-0.00116506244,0)))
	edges.append(L(V(-0.00535362912,-0.00116506244,0),V(-0.0049249584,-0.0017236948,0)))
	edges.append(L(V(-0.0049249584,-0.0017236948,0),V(-0.00436631842,-0.0021523706,0)))
	edges.append(L(V(-0.00436631842,-0.0021523706,0),V(-0.00371575838,-0.00242183666,0)))
	edges.append(L(V(-0.00371575838,-0.00242183666,0),V(-0.0030176216,-0.0025137364,0)))
	edges.append(L(V(-0.0030176216,-0.0025137364,0),V(0.0084823808,-0.0025137364,0)))
	edges.append(L(V(0.0084823808,-0.0025137364,0),V(0.00887936502,-0.0024347805,0)))
	edges.append(L(V(0.00887936502,-0.0024347805,0),V(0.0092159074,-0.0022099016,0)))
	edges.append(L(V(0.0092159074,-0.0022099016,0),V(0.0094225618,-0.001914779,0)))
	edges.append(L(V(0.0094225618,-0.001914779,0),V(0.0094844108,-0.0017448784,0)))
	edges.append(L(V(0.0094844108,-0.0017448784,0),V(0.0095197422,-0.0014779244,0)))
	edges.append(L(V(0.0095197422,-0.0014779244,0),V(0.009525,-0.000812673,0)))
	edges.append(L(V(0.009525,-0.000812673,0),V(0.00932923458,-0.0008111236,0)))
	edges.append(L(V(0.00932923458,-0.0008111236,0),V(0.0099197414,-0.0008111236,0)))
	edges.append(L(V(0.0099197414,-0.0008111236,0),V(0.0099197414,-0.0004163822,0)))
	edges.append(L(V(0.0099197414,-0.0004163822,0),V(0.0091302586,-0.0004163822,0)))
	edges.append(L(V(0.0091302586,-0.0004163822,0),V(0.0091250008,-0.0014748256,0)))
	edges.append(L(V(0.0091250008,-0.0014748256,0),V(0.0093223715,-0.001476375,0)))
	edges.append(L(V(0.0093223715,-0.001476375,0),V(0.0091250008,-0.001476375,0)))
	edges.append(L(V(0.0091250008,-0.001476375,0),V(0.00903890496,-0.00179768246,0)))
	edges.append(L(V(0.00903890496,-0.00179768246,0),V(0.00880368826,-0.00203289916,0)))
	edges.append(L(V(0.00880368826,-0.00203289916,0),V(0.0084823808,-0.002118995,0)))
	edges.append(L(V(0.0084823808,-0.002118995,0),V(-0.0030176216,-0.002118995,0)))
	edges.append(L(V(-0.0030176216,-0.002118995,0),V(-0.00372917212,-0.00200630028,0)))
	edges.append(L(V(-0.00372917212,-0.00200630028,0),V(-0.00437107076,-0.00167923972,0)))
	edges.append(L(V(-0.00437107076,-0.00167923972,0),V(-0.00488048808,-0.00116982748,0)))
	edges.append(L(V(-0.00488048808,-0.00116982748,0),V(-0.00520755626,-0.00052793138,0)))
	edges.append(L(V(-0.00520755626,-0.00052793138,0),V(-0.0053202586,0.0001836166,0)))
	edges.append(L(V(-0.0053202586,0.0001836166,0),V(0.0069726556,0.0001836166,0)))
	edges.append(L(V(0.0069726556,0.0001836166,0),V(0.0072094852,0.0004204716,0)))
	edges.append(L(V(0.0072094852,0.0004204716,0),V(0.0072094852,0.0019501866,0)))
	edges.append(L(V(0.0072094852,0.0019501866,0),V(0.0084952586,0.0019501866,0)))
	edges.append(L(V(0.0084952586,0.0019501866,0),V(0.0084952586,0.0004204716,0)))
	edges.append(L(V(0.0084952586,0.0004204716,0),V(0.0087321136,0.0001836166,0)))
	edges.append(L(V(0.0087321136,0.0001836166,0),V(0.0099197414,0.0001836166,0)))
	edges.append(L(V(0.0099197414,0.0001836166,0),V(0.0099197414,0.0005783834,0)))
	edges.append(L(V(0.0099197414,0.0005783834,0),V(0.00889,0.0005783834,0)))
	edges.append(L(V(0.00889,0.0005783834,0),V(0.00889,0.0021080984,0)))
	edges.append(L(V(0.00889,0.0021080984,0),V(0.008653145,0.002344928,0)))
	edges.append(L(V(0.008653145,0.002344928,0),V(0.0070515988,0.002344928,0)))
	edges.append(L(V(0.0070515988,0.002344928,0),V(0.0068147438,0.0021080984,0)))
	edges.append(L(V(0.0068147438,0.0021080984,0),V(0.0068147438,0.0005783834,0)))
	edges.append(L(V(0.0068147438,0.0005783834,0),V(-0.0053202586,0.0005783834,0)))
	edges.append(L(V(-0.0053202586,0.0005783834,0),V(-0.00520755626,0.00128993138,0)))
	edges.append(L(V(-0.00520755626,0.00128993138,0),V(-0.00488048808,0.00193182748,0)))
	edges.append(L(V(-0.00488048808,0.00193182748,0),V(-0.00437107076,0.00244123972,0)))
	edges.append(L(V(-0.00437107076,0.00244123972,0),V(-0.00372917212,0.00276830028,0)))
	edges.append(L(V(-0.00372917212,0.00276830028,0),V(-0.0030176216,0.002880995,0)))
	edges.append(L(V(-0.0030176216,0.002880995,0),V(0.0084823808,0.002880995,0)))
	edges.append(L(V(0.0084823808,0.002880995,0),V(0.00880368826,0.00279489916,0)))
	edges.append(L(V(0.00880368826,0.00279489916,0),V(0.00903890496,0.00255968246,0)))
	edges.append(L(V(0.00903890496,0.00255968246,0),V(0.0091250008,0.002238375,0)))
	edges.append(L(V(0.0091250008,0.002238375,0),V(0.0093223715,0.002238375,0)))
	edges.append(L(V(0.0093223715,0.002238375,0),V(0.0091250008,0.0022368256,0)))
	edges.append(L(V(0.0091250008,0.0022368256,0),V(0.0091302586,0.0011783822,0)))
	edges.append(L(V(0.0091302586,0.0011783822,0),V(0.0099197414,0.0011783822,0)))
	edges.append(L(V(0.0099197414,0.0011783822,0),V(0.0099197414,0.0015731236,0)))
	sketch.addEdges(edges)
	part=empro.geometry.Model()
	part.recipe.append(empro.geometry.Cover(sketch))
	part.coordinateSystem.translate(V(0,0,0.0008))
	part.meshParameters=empro.mesh.ModelMeshParameters()
	part.meshParameters.priority=142
	empro.toolkit.applyMaterial(part,materials["cond"])
	assembly.append(part)
	assembly.name="cond"
	empro.activeProject.geometry().append(assembly)
	assembly=empro.geometry.Assembly()
	sketch=empro.geometry.Sketch()
	edges=[]
	edges.append(L(V(-0.005715,0.0064007364,0),V(-0.005715,-0.0056387364,0)))
	edges.append(L(V(-0.005715,-0.0056387364,0),V(0.0099197414,-0.0056387364,0)))
	edges.append(L(V(0.0099197414,-0.0056387364,0),V(0.0099197414,0.0064007364,0)))
	edges.append(L(V(0.0099197414,0.0064007364,0),V(-0.005715,0.0064007364,0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex1",V(-0.005715,"-0.00251374-yLowerExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex2",V(0.00991974,"-0.00251374-yLowerExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex3",V(0.00991974,"0.00327574+yUpperExtension",0)))
	sketch.constraintManager().append(empro.geometry.FixedPositionConstraint("vertex0",V(-0.005715,"0.00327574+yUpperExtension",0)))
	sketch.addEdges(edges)
	part=empro.geometry.Model()
	part.recipe.append(empro.geometry.Cover(sketch))
	part.meshParameters=empro.mesh.ModelMeshParameters()
	part.meshParameters.includeInMesh=False
	part.meshParameters.priority=130
	empro.toolkit.applyMaterial(part,materials["closed_bottom"])
	assembly.append(part)
	assembly.name="closed_bottom"
	empro.activeProject.geometry().append(assembly)
	assembly=empro.geometry.Assembly()
	assembly.name="bondwires"
	mask_heights={}
	mask_heights[1]=(0.0008, 0.0008)
	s3dc_files={"lib":{}}
	s3dc_files["libS3D.xml"]="eJyzCTZ2cbbjstGH0AAcBANS"
	if ("create_3d_components" in empro.toolkit.ads_import.Import_session.__dict__):
		session.create_3d_components(s3dc_files, mask_heights)
	session.renumber_waveguides()
	session.notify_success()

def portNbToName():
	portNbToName={}
	portNbToName[1]= ("P1",1)
	portNbToName[2]= ("P2_P3_P4",1)
	portNbToName[3]= ("P2_P3_P4",2)
	portNbToName[4]= ("P2_P3_P4",3)
	portNbToName[5]= ("P5",-1)
	portNbToName[6]= ("P6",-1)
	portNbToName[7]= ("P7",-1)
	return portNbToName

def radiationPossible():
	return True

def main():
	try:
		ads_import()
	except Exception:
		empro.toolkit.ads_import.notify_failure()
		raise

if __name__=="__main__":
	main()
	del ads_import
